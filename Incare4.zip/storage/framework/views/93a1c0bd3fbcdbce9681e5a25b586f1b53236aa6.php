
<?php $__env->startComponent('mail::message'); ?>
Hello **<?php echo e($first_name); ?> <?php echo e($last_name); ?>**,





<p>Thanks for your interest in joining Incare, Click the button below to login</p>
<?php $__env->startComponent('mail::button', ['url' => 'https://incare.ng/login']); ?>
    Login Here
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


Regards,  <br>
<b><?php echo e(config('app.name')); ?></b>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/emails/registration.blade.php ENDPATH**/ ?>