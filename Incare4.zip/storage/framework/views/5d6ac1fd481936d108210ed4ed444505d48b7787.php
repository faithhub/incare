<script>
    function payWithPaystack(amount, id){
    var handler = PaystackPop.setup({
    key: '<?php echo e(env('PAYSTACK_KEY')); ?>',
    email: "<?php echo e(Auth::user()->email); ?>",
    amount: amount+'00',
    currency: "NGN",
    ref: Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    firstname: "<?php echo e(Auth::user()->first_name); ?>",
    lastname: "<?php echo e(Auth::user()->last_name); ?>",
    // label: "Optional string that replaces customer email"
    metadata: {
     custom_fields: [
        {
            display_name: "<?php echo e(Auth::user()->email); ?>" + " " + "<?php echo e(Auth::user()->email); ?>",
            variable_name: "mobile_number",
            value: "<?php echo e(Auth::user()->mobile); ?>"
        }
     ]
    },
    callback: function(response){
        $.ajax({
          type: "post",
          url: "make-payment",
          data: {
            "_token": "<?php echo e(csrf_token()); ?>",
            'plan_id': id,
            'user_id': "<?php echo e(Auth::user()->id); ?>",
            'plan': '1',
            'amount': amount,
            'status': response.status,
            'reference': response.reference,
            'message': response.message,
            'transaction': response.transaction,
            'trxref': response.trxref,
          },
          success: function (response) {
            // console.log(response)
            if(response == true){
              window.location.href = "<?php echo e(url('care-giver/transactions')); ?>";
            }else{
              window.location.href = "<?php echo e(url('care-giver/plans')); ?>";
            }
          }
        });

      // alert('success. transaction ref is ' + response);
      // console.log(response);

    },
    onClose: function(){
      alert('Are you sure you want to close and cancel this payment?');
    }
    });
    handler.openIframe();
    }
    </script>
<?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/care_giver/layouts/includes/payment.blade.php ENDPATH**/ ?>