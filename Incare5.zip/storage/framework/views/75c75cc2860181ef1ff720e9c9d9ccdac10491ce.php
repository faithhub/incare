
<?php $__env->startSection('user'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
            <div class="section-heading">
                <h2 class="sec__title">Transactions</h2>
            </div><!-- end section-heading -->
            <ul class="list-items d-flex align-items-center">
                <li class="active__list-item"><a href="#">Home</a></li>
                <li class="active__list-item"><a href="#">Dashboard</a></li>
                <li>Transactions</li>
            </ul>
        </div><!-- end breadcrumb-content -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->
<div class="row mt-5">
    <div class="col-lg-12">
        <div class="billing-form-item">
            <div class="billing-title-wrap">
                <h3 class="widget-title pb-0">My Transactions</h3>
                <div class="title-shape margin-top-10px"></div>
            </div><!-- billing-title-wrap -->
            <div class="billing-content pb-0">
                <div class="manage-job-wrap">
                    <div class="table-responsive">
                        <table class="table" id="myTable" width="100%">
                            <thead>
                            <tr>
                                <th>Payment Name</th>
                                <th>Amount Paid</th>
                                <th>Plan Duration</th>                                
                                <th>Status</th>                              
                                <th>Reference ID</th>
                                <th>TRXREF</th>
                                <th>Payment Date</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="manage-candidate-wrap">
                                        <h2 class="widget-title pb-0 font-size-15"><?php echo e($transaction->plan->plan_name); ?></h2>
                                        </div><!-- end manage-candidate-wrap -->
                                    </td>
                                    <td class="font-weight-semi-bold">
                                        ₦<?php echo e($transaction->amount); ?>

                                    </td>
                                    <td><?php echo e($transaction->plan->plan_type); ?></td>
                                    <td class="text-center"><span class="badge badge-success p-1"><?php echo e($transaction->status); ?></span></td>
                                    <td><?php echo e($transaction->reference); ?></td>
                                    <td><?php echo e($transaction->trxref); ?></td>
                                    <td><?php echo e(date('D, M j, Y \a\t g:ia', strtotime($transaction->created_at))); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!-- end billing-content -->
        </div><!-- end billing-form-item -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/employer/transaction/index.blade.php ENDPATH**/ ?>