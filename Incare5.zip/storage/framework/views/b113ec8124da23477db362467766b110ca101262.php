
<?php $__env->startSection('care_giver'); ?>
<div class="row">
  <div class="col-lg-12">
    <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
      <div class="section-heading">
        <h2 class="sec__title">Job Details</h2>
      </div><!-- end section-heading -->
      <ul class="list-items d-flex align-items-center">
        <li class="active__list-item"><a href="#">Home</a></li>
        <li class="active__list-item"><a href="#">Dashboard</a></li>
        <li>Job Details</li>
      </ul>
    </div><!-- end breadcrumb-content -->
  </div><!-- end col-lg-12 -->
</div><!-- end row -->

<div class="row mt-5">
  <div class="col-lg-12">
    <div class="billing-form-item">
      <div class="billing-title-wrap">
        <h3 class="widget-title pb-0">Job Details</h3>
        <div class="title-shape margin-top-10px"></div>
      </div><!-- billing-title-wrap -->
      <div class="billing-content pb-0">
        <div class="manage-job-wrap">
          <?php if($job_apply->count() > 0): ?>
          <?php if($job_apply[0]['status'] == 'Approved'): ?>
          <h3 class="widget-title font-size-30 text-black pb-1 mb-2">Start Work Now</h3>
          <div class="text-right">
            <div class="bread-action">
              <ul class="info-list">
                <li class="d-inline-block mb-0">
                  <?php if($job[0]['status'] == 'Delivered'): ?>
                  <button disabled style="cursor: no-drop" class="btn btn-success mb-2">Start Work</button>
                  <?php else: ?>
                  <form method="POST" action="<?php echo e(url('care-giver/start-job')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="employer_id" value="<?php echo e($job[0]['employer_id']); ?>">
                    <input type="hidden" name="job_id" value="<?php echo e($job[0]['id']); ?>">
                    <input type="hidden" name="amount" value="<?php echo e($job[0]['amount']); ?>">
                    <button type="submit" class="btn btn-success mb-2">Start Work</button>
                  </form>
                  <?php endif; ?>
                </li>
                <li class="d-inline-block mb-0">
                  <?php if($job[0]['status'] == 'Delivered'): ?>
                  <button disabled style="cursor: no-drop" class="btn btn-success mb-2">Delivered</button>
                  <?php else: ?>
                  <form method="POST" action="<?php echo e(url('care-giver/deliver-work')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="job_id" value="<?php echo e($job[0]['id']); ?>">
                    <button type="submit" class="btn btn-success mb-2">Deliver Work</button>
                  </form>
                  <?php endif; ?>
                </li>
              </ul>
            </div>
          </div>
          <div class="row mb-5">
            <div class="col-12">
              <?php if($job_start->count() > 0): ?>
              <div class="manage-candidate-wrap pb-4">
                <div class="bread-details d-flex">
                  <div class="table-responsive">
                    <table class="table" width="100%">
                      <thead>
                        <td>S/N</td>
                        <td>Time Started</td>
                        <td>End Wort At</td>
                        <td>Working Hours Used</td>
                        <td>Amount Worked</td>
                        <td>Payment Status</td>
                        <td>Stop Work</td>
                        <td>Cancel Work</td>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $job_start; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $start): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                          <td><?php echo e($sn++); ?></td>
                          <td><?php echo e(date('D, M j, Y \a\t h:i:s A', strtotime($start->created_at))); ?></td>
                          <td>
                            <?php if($start->done == 'Yes'): ?>
                            <?php echo e(date('D, M j, Y \a\t h:i:s A', strtotime($start->date_end))); ?>

                            <?php else: ?>
                            <span class="btn-sm btn-success">Running</span>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if($start->done == 'Yes'): ?>
                            <?php echo e(date('H:i:s', $start->created_at->diffInSeconds($start->date_end))); ?>

                            <?php else: ?>
                            <span class="btn-sm btn-success">Running</span>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if($start->done == 'Yes'): ?>
                            <span class="text-success"><b>₦<?php echo e($start->amount_worked); ?></b></span>
                            <?php else: ?>
                            <span class="btn-sm btn-success">Running</span>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if($start->done == 'Yes'): ?>
                            <?php if($start->paid == 'Yes'): ?>
                            <span class="btn-sm btn-success">Paid</span>
                            <?php else: ?>
                            <span class="btn-sm btn-warning">Not Paid</span>
                            <?php endif; ?>
                            <?php else: ?>
                            <span class="btn-sm btn-success">Running</span>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if($start->done == 'Yes'): ?>
                            <button disabled style="cursor: no-drop" class="btn btn-sm btn-danger mb-1">Work Ended</button><br>
                            <?php else: ?>
                            <form method="POST" action="<?php echo e(url('care-giver/end-job')); ?>">
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="employer_id" value="<?php echo e($job[0]['employer_id']); ?>">
                              <input type="hidden" name="job_id" value="<?php echo e($job[0]['id']); ?>">
                              <input type="hidden" name="amount" value="<?php echo e($job[0]['amount']); ?>">
                              <input type="hidden" name="id" value="<?php echo e($start->id); ?>">
                              <button type="submit" class="btn btn-sm btn-danger mb-1">End Work</button><br>
                            </form>
                            <?php endif; ?>
                          </td>
                          <td>
                            <div class="manage-candidate-wrap">
                              <div class="bread-action pt-0">
                                <ul class="info-list">
                                  <?php if($start->paid != 'Yes'): ?>
                                  <li class="d-inline-block"><a href="#"><i data-toggle="modal" data-target="#delete-work-history<?php echo e($start->id); ?>" class="la la-trash" data-toggle="tooltip" data-placement="top" title="Delete Work"></i></a></li>
                                  <?php endif; ?>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>

                        <!-- Modal Delete -->
                        <div class="modal fade" id="delete-work-history<?php echo e($start->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                              <div class="modal-body mt-2 mb-2 text-center">
                                <h3 style="color: black">Are you sure you want to delete this work history?</h3>
                                <form method="POST" action="<?php echo e(url('care-giver/delete-work-done')); ?>">
                                  <?php echo csrf_field(); ?>
                                  <input type="hidden" name="id" value="<?php echo e($start->id); ?>">
                                  <button type="submit" class="btn btn-success m-2">Yes</button>
                                  <button type="button" class="btn btn-dark m-2" data-dismiss="modal" aria-label="Close">No</button>
                                </form>
                              </div>
                            </div>
                          </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <?php else: ?>
              <?php endif; ?>
            <?php if(isset($reviews) && $reviews != null): ?>
              <div class="card mt-4">
                <div class="card-header">
                  Reviews
                </div>
                <div class="card-body">
                      <?php if($reviews->count() > 0 ? ($sender_status->count() > 0) : false): ?>
                      <?php else: ?>
                      <form method="POST" action="<?php echo e(url('care-giver/review')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="employer_id" value="<?php echo e($user->id); ?>">
                        <input type="text" name="work_done_id" value="<?php echo e($job[0]->id); ?>">
                        <div class="form-group">
                          <textarea name="review" id="" class="form-control" cols="30" rows="5"></textarea>
                        </div>
                        <div class="text-right">
                          <button type="submit" class="btn btn-success">Send</button>
                        </div>
                      </form>
                      <?php endif; ?>
                      <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($review->sender_id == Auth::User()->id): ?>
                      <div class="media mb-4">
                        <div class="media-left media-middle">
                          <a href="#">
                            <img class="media-object mr-3" style="width: auto; height: 50px;" src="<?php echo e(Auth::User()->avatar != null ? asset('uploads/profile_pictures/'.Auth::User()->avatar) : asset('web/images/avatar.png')); ?>" alt="<?php echo e(Auth::User()->first_name); ?>">
                          </a>
                        </div>
                        <div class="media-body">
                          <h5 class="media-heading"><?php echo e(Auth::User()->first_name); ?> <?php echo e(Auth::User()->last_name); ?></h5>
                          <p><?php echo e($review->review); ?></p>
                          <small><i><?php echo e($review->created_at->diffForHumans()); ?></i></small>
                        </div>
                      </div>
                      <?php else: ?>
                      <div class="media mb-4">
                        <div class="media-left media-middle">
                          <a href="#">
                            <img class="media-object mr-3" style="width: auto; height: 50px;" src="<?php echo e($user->avatar != null ? asset('uploads/profile_pictures/'.$user->avatar) : asset('web/images/avatar.png')); ?>" alt="<?php echo e($user->first_name); ?>" alt="<?php echo e($user->first_name); ?>">
                          </a>
                        </div>
                        <div class="media-body">
                          <h5 class="media-heading"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> </h5>
                          <p><?php echo e($review->review); ?></p>
                          <small><i><?php echo e($review->created_at->diffForHumans()); ?></i></small>
                        </div>
                      </div>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
            <?php endif; ?>
            <div class="row mb-5 mt-5">
              <div class="col-lg-12 mb-2">
                <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
                  <div class="bread-details d-flex">
                    <div class="bread-img flex-shrink-0">
                      <img src="<?php echo e(asset('uploads/jobs/'.$job[0]['avatar'])); ?>" alt="">
                    </div>
                    <div class="job-detail-content">
                      <h2 class="widget-title font-size-30 text-black pb-1"><?php echo e($job[0]['job_title']); ?></h2>
                      <p class="font-size-16 mt-1 text-black">
                        <span class="mr-2 mb-2 d-inline-block"><i class="la la-briefcase mr-1"></i>Category: <?php echo e($job[0]['cat']['name']); ?></span>
                        <br>
                        <span class="mr-2 mb-2 d-inline-block"><i class="la la-briefcase mr-1"></i>Sub Category: <?php echo e($job[0]['sub']['name']); ?></span>
                      </p>
                    </div><!-- end job-detail-content -->
                  </div><!-- end bread-details -->
                  <div class="bread-action">
                    <ul class="listing-info">
                      
                      <li>
                        <?php if($check > 0): ?>
                        <button type="button" disabled class="btn border-0 p-3 btn-success" style="cursor: no-drop">Applied</button>
                        <?php else: ?>
                        <form method="POST" action="<?php echo e(url('care-giver/apply-job')); ?>">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="id" value="<?php echo e($job[0]['id']); ?>">
                          <button type="submit" class="btn border-0 p-3 btn-success">Apply Now</button>
                        </form>
                        <?php endif; ?>

                      </li>
                    </ul>
                  </div><!-- end bread-action -->
                </div><!-- end breadcrumb-content -->
              </div>
              <div class="col-lg-7">
                <div class="single-job-wrap">
                  <div class="job-description padding-bottom-35px">
                    <h2 class="widget-title">Description:</h2>
                    <div class="title-shape"></div>
                    <p class="mt-3 mb-3">
                      <?php echo e($job[0]['job_description']); ?>

                    </p>
                  </div><!-- end job-description -->
                </div><!-- end single-job-wrap -->
              </div><!-- end col-lg-8 -->
              <div class="col-lg-5">
                <div class="sidebar mt-0">
                  <div class="sidebar-widget">
                    <div class="billing-form-item mb-0">
                      <div class="billing-title-wrap">
                        <h3 class="widget-title">Job Details</h3>
                        <div class="title-shape"></div>
                      </div><!-- billing-title-wrap -->
                      <div class="billing-content">
                        <div class="info-list static-info">
                          <ul>
                            <?php if($job_apply->count() > 0): ?>
                            <li class="mb-3 d-flex align-items-center">
                              <p><i class="la la-tint"></i> <span class="color-text-2 font-weight-medium mr-1">Job Status:</span>
                                <?php if($job_apply[0]['status'] == 'Approved'): ?>
                                <span class="badge badge-success p-1"><?php echo e($job_apply[0]['status']); ?></span>
                                <?php elseif($job_apply[0]['status'] == 'Denied'): ?>
                                <span class="badge badge-danger p-1"><?php echo e($job_apply[0]['status']); ?></span>
                                <?php else: ?>
                                <span class="badge badge-warning p-1"><?php echo e($job_apply[0]['status']); ?></span>
                                <?php endif; ?>
                              </p>
                            </li>
                            <?php endif; ?>
                            <li class="mb-3 d-flex align-items-center">
                              <p><i class="la la-tint"></i> <span class="color-text-2 font-weight-medium mr-1">Job Title:</span> <?php echo e($job[0]['job_title']); ?></p>
                            </li>
                            <li class="mb-3 d-flex align-items-center">
                              <p><i class="la la-briefcase"></i> <span class="color-text-2 font-weight-medium mr-1">Job Category:</span> <?php echo e($job[0]['cat']['name']); ?></p>
                            </li>
                            <li class="mb-3 d-flex align-items-center">
                              <p><i class="la la-briefcase"></i> <span class="color-text-2 font-weight-medium mr-1">Job Sub Category:</span> <?php echo e($job[0]['sub']['name']); ?></p>
                            </li>
                            <li class="mb-3 d-flex align-items-center">
                              <p><i class="la la-map-marker"></i> <span class="color-text-2 font-weight-medium mr-1">City:</span> <?php echo e($job[0]['city']); ?></p>
                            </li>
                            <li class="mb-3 d-flex align-items-center">
                              <p><i class="la la-map-marker"></i> <span class="color-text-2 font-weight-medium mr-1">Location:</span> <?php echo e($job[0]['address']); ?></p>
                            </li>
                            <li class="mb-3 d-flex align-items-center">
                              <p><i class="la la-phone"></i> <span class="color-text-2 font-weight-medium mr-1">Mobile:</span> <?php echo e($job[0]['mobile']); ?></p>
                            </li>
                            <li class="mb-3 d-flex align-items-center">
                              <p><i class="la la-users"></i> <span class="color-text-2 font-weight-medium mr-1">Offered Amount Per Hour:</span> ₦<?php echo e($job[0]['amount']); ?></p>
                            </li>
                            <li class="mb-3 d-flex align-items-center">
                              <p><i class="la la-calendar"></i> <span class="color-text-2 font-weight-medium mr-1">Posted Date:</span> <?php echo e(date('D, M j, Y \a\t g:ia', strtotime($job[0]['created_at']))); ?></p>
                            </li>
                            <li class="mb-3 d-flex align-items-center">
                              <p><i class="la la-bullhorn"></i> <span class="color-text-2 font-weight-medium mr-1">Application Ends On:</span> <?php echo e(date('D, M j, Y \a\t g:ia', strtotime($job[0]['date_end']))); ?></p>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div><!-- end sidebar-widget -->
                </div><!-- end sidebar -->
              </div><!-- end col-lg-4 -->
            </div>
          </div>
        </div><!-- end billing-content -->
      </div><!-- end billing-form-item -->
    </div><!-- end col-lg-12 -->
  </div><!-- end row -->
</div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('care_giver.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/care_giver/jobs/view_job.blade.php ENDPATH**/ ?>