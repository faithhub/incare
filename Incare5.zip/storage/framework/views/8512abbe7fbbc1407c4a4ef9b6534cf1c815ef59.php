<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Incare - <?php echo e($title ?? request()->segment(1)); ?></title>
    <!-- Favicon -->
    <link rel="icon" href="images/favicon.png">

    <!-- Google Fonts -->
     <link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:100,300,400,500,700,900&amp;display=swap" rel="stylesheet">
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css">

    <!-- Template CSS Files -->
    <?php echo $__env->make('web.layouts.includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<!-- start per-loader -->

<!-- end per-loader -->


<!-- ================================
            START HEADER AREA
================================= -->
<?php echo $__env->make('web.layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
<?php echo $__env->make('web.layouts.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ================================
         END HEADER AREA
================================= -->


<?php echo $__env->yieldContent('content'); ?>


<!-- ================================
       START FOOTER AREA
================================= -->
<?php echo $__env->make('web.layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ================================
       START FOOTER AREA
================================= -->

<!-- start back-to-top -->
<div id="back-to-top">
    <i class="fa fa-angle-up" title="Go top"></i>
</div>
<!-- end back-to-top -->

<!-- Template JS Files -->
<?php echo $__env->make('web.layouts.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Mirrored from techydevs.com/demos/themes/html/zobstar/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 22 Oct 2020 09:15:44 GMT -->
</html><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/web/layouts/app.blade.php ENDPATH**/ ?>