
<?php $__env->startSection('user'); ?>
<div class="row">
  <div class="col-lg-12">
    <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
      <div class="section-heading">
        <h2 class="sec__title">Care Giver Profile</h2>
      </div><!-- end section-heading -->
      <ul class="list-items d-flex align-items-center">
        <li class="active__list-item"><a href="#">Home</a></li>
        <li class="active__list-item"><a href="#">Dashboard</a></li>
        <li>Care Giver Profile</li>
      </ul>
    </div><!-- end breadcrumb-content -->
  </div><!-- end col-lg-12 -->
</div><!-- end row -->

<div class="row mt-5">
  <div class="col-lg-12">
    <div class="billing-form-item">
      <div class="billing-title-wrap">
        <h3 class="widget-title pb-0"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> Profile</h3>
        <div class="title-shape margin-top-10px"></div>
      </div><!-- billing-title-wrap -->
      <div class="billing-content pb-0">
        <div class="manage-job-wrap">
          <div class="row mb-5">
            <div class="col-lg-12 mb-2">
              <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
                <div class="bread-details d-flex">
                  <div class="bread-img flex-shrink-0">
                    <img src="<?php echo e($user->avatar != null ? asset('uploads/profile_pictures/'.$user->avatar) : asset('web/images/avatar.png')); ?>" alt="">
                  </div>
                  <div class="job-detail-content">
                    <h2 class="widget-title font-size-30 text-black pb-1"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h2>
                    <p class="font-size-16 mt-1 text-black">
                      <span class="mr-2 mb-2 d-inline-block"><i class="la la-envelope mr-1"></i><?php echo e($user->email); ?></span>
                      <br>
                      <span class="mr-2 mb-2 d-inline-block"><i class="la la-phone mr-1"></i><?php echo e($user->mobile ?? 'Not Uploaded'); ?></span>
                      <br>
                      <span class="mr-2 mb-2 d-inline-block"><i class="la la-map-marker mr-1"></i><?php echo e($user->address ?? 'Not Uploaded'); ?></span>
                    </p>
                  </div><!-- end job-detail-content -->
                </div><!-- end bread-details -->
                <div class="bread-action">
                  <ul class="listing-info">
                  </ul>
                </div><!-- end bread-action -->
              </div><!-- end breadcrumb-content -->
            </div>
            <div class="col-lg-12">
              <div class="single-job-wrap">
                <div class="job-description padding-bottom-35px">
                  <h2 class="widget-title">Reviews:</h2>
                  <div class="title-shape"></div>
                  <?php if($reviews->count() > 0): ?>                      
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="media mb-4 mt-4">
                        <div class="media-left media-middle">
                        <a href="#">
                            <img class="media-object mr-3" style="width: auto; height: 50px;" src="<?php echo e($review->employer->avatar != null ? asset('uploads/profile_pictures/'.$review->employer->avatar) : asset('web/images/avatar.png')); ?>" alt="<?php echo e($review->employer->first_name); ?>">
                        </a>
                        </div>
                        <div class="media-body">
                        <h5 class="media-heading"><?php echo e($review->employer->first_name); ?> <?php echo e($review->employer->last_name); ?></h5>
                        <p><?php echo e($review->review); ?></p>
                        <small><i><?php echo e($review->created_at->diffForHumans()); ?></i></small>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>                      
                  <p class="mt-3 mb-3">
                      No Review Yet
                  </p>
                  <?php endif; ?>
                </div><!-- end job-description -->
              </div><!-- end single-job-wrap -->
            </div><!-- end col-lg-8 -->
            
          </div>
        </div>
      </div><!-- end billing-content -->
    </div><!-- end billing-form-item -->
  </div><!-- end col-lg-12 -->
</div><!-- end row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/employer/jobs/care_giver.blade.php ENDPATH**/ ?>