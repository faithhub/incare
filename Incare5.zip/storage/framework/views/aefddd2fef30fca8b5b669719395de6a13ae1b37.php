


    <!-- Template CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('web/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/font-awesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/line-awesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/daterangepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/jquery-ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/jquery.filer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/jquery.filer-dragdropbox-theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('web/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css"><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/web/layouts/includes/style.blade.php ENDPATH**/ ?>