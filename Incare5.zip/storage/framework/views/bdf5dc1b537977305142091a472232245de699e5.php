

<script src="<?php echo e(asset('web/js/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/isotope-3.0.6.min.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/purecounter.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/jquery.filer.min.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/smooth-scrolling.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/progresscircle.js')); ?>"></script>
<script src="<?php echo e(asset('web/js/main.js')); ?>"></script><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/web/layouts/includes/script.blade.php ENDPATH**/ ?>