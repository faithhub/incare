
<?php $__env->startSection('content'); ?>




<!-- Popular -->

<div class="popular page_section" style="margin-top: 4rem">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="section_title text-center">
                    <h1>Contact US</h1>
                </div>
            </div>
        </div>

        <div class="row course_boxes">
            <!-- Popular Course Item -->
            <div class="col-lg-8">
                <div class="card p-3">
                    <form>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="" class="form-control" placeholder="Full Name">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="" class="form-control" placeholder="Email Address">
                        </div>
                        <div class="form-group">
                            <label>Message</label>
                            <textarea class="form-control" rows="4" placeholder="Your Message here!"></textarea>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-block" style="background-color: #006600; color:white">Submit</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Popular Course Item -->
            <div class="col-lg-4">
                <div class="">
                    <h3>Join Courses</h3>
                    <p>
                        In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, 
                        vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, 
                        finibus tortor fermentum. Etiam eu purus nec eros varius luctus. 
                        Praesent finibus risus facilisis ultricies. Etiam eu purus nec eros varius luctus.
                    </p>
                    <ul>
                        <li class="contact_info_item m-3" style="display: inline-flex">
                            <span class="fa fa-address-book m-1"></span>
                            
                            Blvd Libertad, 34 m05200 Arévalo
                        </li>
                        <li class="contact_info_item m-3" style="display: inline-flex">
                            <span class="fa fa-phone m-1"></span>
                            
                            +234 081 6818 1969
                        </li>
                        <li class="contact_info_item m-3" style="display: inline-flex">
                            <span class="fa fa-envelope m-1"></span>
                            
                            davidshine4jesus@gmail.com
                        </li>
                    </ul>

                </div>
            </div>

        </div>
    </div>		
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\laravel\GraceHand\resources\views/web/contact.blade.php ENDPATH**/ ?>