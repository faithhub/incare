
<?php $__env->startSection('admin'); ?>    
<div class="row">
    <div class="col-lg-12">
        <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
            <div class="section-heading">
                <h2 class="sec__title line-height-45">Users</h2>
            </div><!-- end section-heading -->
            <ul class="list-items d-flex align-items-center">
                <li class="active__list-item"><a href="index.html">Home</a></li>
                <li class="active__list-item">Dashboard</li>
                <li>Users</li>
            </ul>
        </div><!-- end breadcrumb-content -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->
<div class="row mt-5">
    <div class="col-lg-12">
        <div class="billing-form-item">
            <div class="billing-title-wrap">
                <h3 class="widget-title pb-0">Users Details </h3>
                <div class="title-shape margin-top-10px"></div>
            </div><!-- billing-title-wrap -->
            <div class="billing-content pb-0">
                <div class="manage-job-wrap">
                    <div class="table-responsive">
                        <table class="table" id="myTable" width="100%">
                            <thead>
                            <tr>
                                <th>User</th>
                                <th>Type</th>
                                <th>Date Registered</th>
                                
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="bread-details d-flex">
                                                <div class="bread-img flex-shrink-0">
                                                    <a href="candidate-details.html" class="d-block">
                                                        <?php if($user->avatar != null): ?>
                                                        <img src="<?php echo e(asset('uploads/profile_pictures/'.$user->avatar)); ?>" alt="">                                                            
                                                        <?php else: ?>
                                                        <img src="<?php echo e(asset('web/images/small-team4.jpg')); ?>" alt="">                                                            
                                                        <?php endif; ?>
                                                    </a>
                                                </div>
                                                <div class="manage-candidate-content">
                                                    <h2 class="widget-title pb-2"><a href="candidate-details.html" class="color-text-2"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></a></h2>
                                                    <p class="font-size-15">
                                                        <span class="mr-2"><?php echo e($user->email); ?> </span>
                                                    </p>
                                                    <p class="mt-2 font-size-15">
                                                        <span class="mr-2"><i class="la la-map-marker mr-1"></i><?php echo e($user->city); ?>, </span>
                                                        <span class="mr-2"><?php echo e($user->address); ?></span>
                                                    </p>
                                                    
                                                </div><!-- end manage-candidate-content -->
                                            </div>
                                        </td>
                                        <td>
                                            <?php if($user->type == 1): ?>
                                                <span class="badge badge-success note-badge note-badge-bg-2 p-2">Employer</span>
                                            <?php elseif($user->type == 2): ?>
                                                <span class="badge badge-success note-badge note-badge-bg-2 p-2">Care Giver</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e(date('D, M j, Y \a\t g:ia', strtotime($user->created_at))); ?></td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div><!-- end billing-form-item -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/admin/users/index.blade.php ENDPATH**/ ?>