
<!-- ================================
            START HEADER AREA
================================= -->
<header class="header-area">
    <div class="header-menu-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="menu-full-width">
                        <div class="logo">
                            <a href="<?php echo e(url('home')); ?>"><img src="<?php echo e(asset('web/images/logo2.png')); ?>" alt="logo"></a>
                        </div><!-- end logo -->
                        <div class="main-menu-content">
                            <nav>
                                <ul>
                                    <li>
                                        <a href="<?php echo e(url('home')); ?>">Home</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('about')); ?>">About Us</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('contact')); ?>">Contact Us</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('jobs')); ?>">Jobs</a>
                                    </li>
                                </ul>
                            </nav>
                        </div><!-- end main-menu-content -->
                        <div class="logo-right-content">
                            <ul class="author-access-list">
                                <li>
                                    <a href="<?php echo e(url('login')); ?>">Login</a>
                                    <span class="or-text">or</span>
                                    <a href="<?php echo e(url('register')); ?>">Sign up</a>
                                </li>
                                <li>
                                     <a href="<?php echo e(url('employer/post-new-job')); ?>" class="theme-btn">
                                        <span class="la la-plus"></span>
                                        Post a Job
                                    </a>
                                </li>
                            </ul>
                            <div class="side-menu-open">
                                <span class="menu__bar"></span>
                                <span class="menu__bar"></span>
                                <span class="menu__bar"></span>
                            </div><!-- end side-menu-open -->
                        </div><!-- end logo-right-content -->
                    </div><!-- end menu-full-width -->
                </div><!-- end col-lg-12 -->
            </div><!-- end row -->
        </div><!-- end container-fluid -->
    </div><!-- end header-menu-wrapper -->
    <div class="side-nav-container">
        <div class="humburger-menu">
            <div class="humburger-menu-lines side-menu-close"></div><!-- end humburger-menu-lines -->
        </div><!-- end humburger-menu -->
        <div class="side-menu-wrap">
            <ul class="side-menu-ul">
                <li>
                    <a href="<?php echo e(url('home')); ?>">Home</a>
                </li>
                <li>
                    <a href="<?php echo e(url('about')); ?>">About Us</a>
                </li>
                <li>
                    <a href="<?php echo e(url('contact')); ?>">Contact</a>
                </li>
                <li>
                    <a href="<?php echo e(url('jobs')); ?>">Jobs</a>
                </li>
            </ul>
            <div class="side-nav-button">
                <a href="<?php echo e(url('login')); ?>">Login</a>
                <span class="or-text">or</span>
                <a href="<?php echo e(url('register')); ?>">Sign up</a>
                <a href="<?php echo e(url('employer/post-new-job')); ?>" class="theme-btn">Post a Job</a>
            </div><!-- end side-nav-button -->
        </div><!-- end side-menu-wrap -->
    </div><!-- end side-nav-container -->
</header>
<!-- ================================
         END HEADER AREA
================================= --><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/web/layouts/includes/header.blade.php ENDPATH**/ ?>