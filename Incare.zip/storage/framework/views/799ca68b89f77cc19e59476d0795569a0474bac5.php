<script src="<?php echo e(asset('vendor/jquery.2.2.3.min.js')); ?>"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
<script>
	<?php if(Session::has('info')): ?>
		toastr.info("<?php echo e(session('error')); ?>");
	<?php elseif(Session::has('success')): ?>
		toastr.success("<?php echo e(session('success')); ?>", "Success");
	<?php elseif(Session::has('error')): ?>
		toastr.error("<?php echo e(session('error')); ?>", "Something Went Wrong!");
	<?php elseif(Session::has('warning')): ?>
		toastr.warning("<?php echo e(session('warning')); ?>", "Try Again!");
	<?php elseif(Session::has('status')): ?>
		toastr.success("<?php echo e(session('status')); ?>", "Success");
	<?php elseif(Session::has('permission_warning')): ?>
		toastr.warning("<?php echo e(session('permission_warning')); ?>", "Warning!");
	<?php endif; ?>
  </script><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/employer/layouts/includes/alert.blade.php ENDPATH**/ ?>