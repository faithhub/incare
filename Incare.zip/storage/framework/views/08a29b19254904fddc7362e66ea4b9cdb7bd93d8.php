<!DOCTYPE html>
<html lang="en">
<head>
<title>GraceHands</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="GraceHands">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo $__env->make('web.layouts.includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
</head>
<body>

<div class="super_container">
    <!-- Header -->
    <?php echo $__env->make('web.layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
    <!-- Home -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Footer -->
    <?php echo $__env->make('web.layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php echo $__env->make('web.layouts.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\Hp\laravel\GraceHand\resources\views/web/layouts/app.blade.php ENDPATH**/ ?>