
<?php $__env->startComponent('mail::message'); ?>
Hello **<?php echo e(config('app.name')); ?>**,



<p>A message has just been recieved from the contact us page, find the details bellow.</p>

<h3>Name: <?php echo e($name); ?></h3>
<h3>Email: <?php echo e($email); ?></h3>
<h3>Phone: <?php echo e($mobile); ?></h3>
<h3>Reason For Contact: <?php echo e($reason); ?></h3>
<h3>What Is 7 + 5? Spam Protection: <?php echo e($bot); ?></h3>
<h3>Preferred Method Of Communication: <?php echo e($communicate); ?></h3>
<h3>Additional Information: <?php echo e($message); ?></h3>
<h4>Sent on: <?php echo e(date('D, M j, Y \a\t g:ia', strtotime($time))); ?></h4>

Regards,  <br>
<b><?php echo e(config('app.name')); ?></b>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/emails/send_message.blade.php ENDPATH**/ ?>