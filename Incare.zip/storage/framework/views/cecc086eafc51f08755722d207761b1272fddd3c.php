
<?php $__env->startSection('user'); ?>
<div class="row">
  <div class="col-12">
    <div class="dashboard-message-wrapper d-flex">
      <div class="message-sidebar col-12">
        <div class="message-search">
          <div class="contact-form-action">
            <form action="#">
              <div class="form-group mb-0">
                <input class="form-control" type="text" placeholder="Search...">
                <button type="submit" class="submit-btn "><i class="la la-search"></i></button>
              </div>
            </form>
          </div>
        </div><!-- message-search -->
        <div class="message-inbox-item">
          <div class="mess__body">
            <a href="#" class=" d-block message-inbox">
              <div class="mess__item">
                <div class="avatar dot-status">
                  <img src="<?php echo e(asset('web/images/small-team1.jpg')); ?>" alt="Michelle Moreno">
                </div>
                <div class="content">
                  <h4 class="widget-title">Harvey Specter</h4>
                  <p class="text">Oh yeah, did Michael Jordan tell you that?</p>
                  <span class="time color-text-3 font-size-12">2 days ago</span>
                </div>
              </div>
            </a>
          </div><!-- end mess__body -->
        </div><!-- end message-inbox-item -->
      </div><!-- message-sidebar -->
      
      <!-- message-content -->
    </div><!-- end dashboard-message-wrapper -->
  </div><!-- end col -->
</div><!-- end row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/employer/message/index.blade.php ENDPATH**/ ?>