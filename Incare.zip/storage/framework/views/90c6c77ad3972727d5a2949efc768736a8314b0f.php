
<?php $__env->startSection('admin'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
            <div class="section-heading">
                <h2 class="sec__title">Add Job Category</h2>
            </div><!-- end section-heading -->
            <ul class="list-items d-flex align-items-center">
                <li class="active__list-item"><a href="index.html">Home</a></li>
                <li class="active__list-item"><a href="index.html">Dashboard</a></li>
                <li>Add Job Category</li>
            </ul>
            
        </div><!-- end breadcrumb-content -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->

<div class="row mt-5">
    <div class="col-lg-12">
        <div class="billing-form-item">
            <div class="billing-title-wrap">
                <h3 class="widget-title pb-0">Job Category Information</h3>
                <div class="title-shape margin-top-10px"></div>
            </div><!-- billing-title-wrap -->
            <div class="billing-content">
                <div class="contact-form-action">
                    <form method="post">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="input-box">
                                    <label class="label-text">Category</label>
                                    <div class="form-group">
                                        <span class="la la-user form-icon"></span>
                                        <input class="form-control" type="text" name="text" placeholder="Job Category">
                                    </div>
                                </div>
                            </div><!-- end col-lg-6 -->
                            
                            <div class="col-lg-6">
                                <div class="input-box">
                                    <label class="label-text">Sub Category</label>
                                    <div class="form-group">
                                        <select class="category-option-field">
                                            <option value >All Specialism</option>
                                            <option value="1">Category 1</option>
                                            <option value="2">Category 2</option>
                                            <option value="3">Category 3</option>
                                            <option value="4">Category 4</option>
                                            <option value="5">Category 5</option>
                                        </select>
                                    </div>
                                </div>
                            </div><!-- end col-lg-6 -->
                            
                        </div><!-- end row -->
                        <div class="btn-box">
                            <a href="" class="theme-btn">Submit</a>
                        </div>
                    </form>
                </div><!-- end contact-form-action -->
            </div><!-- end billing-content -->
        </div><!-- end billing-form-item -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->
<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Add Sub Category</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form method="POST" action="">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <input class="form-control" type="text" name="name" required placeholder="Job Sub Category">
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success">Add Sub Category</button>
            </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/admin/jobs/category.blade.php ENDPATH**/ ?>