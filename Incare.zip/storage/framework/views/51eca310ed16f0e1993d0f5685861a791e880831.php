
<?php $__env->startSection('user'); ?>
<div class="row">
  <div class="col-12">
    <div class="dashboard-message-wrapper d-flex">
      <div class="message-sidebar col-12">
        <div class="message-search">
          <div class="contact-form-action">
            <form action="#">
              <div class="form-group mb-0">
                <input class="form-control" type="text" placeholder="Search...">
                <button type="submit" class="submit-btn "><i class="la la-search"></i></button>
              </div>
            </form>
          </div>
        </div><!-- message-search -->
        <div class="message-inbox-item">
          <div class="mess__body">
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <a href="<?php echo e(url('care-giver/message', $message[0]['employer']['id'])); ?>" class=" d-block message-inbox">
              <div class="mess__item">
                <div class="avatar">
                  <img src="<?php echo e(asset('uploads/profile_pictures/'.$message[0]['employer']['avatar'])); ?>" alt="<?php echo e($message[0]['employer']['first_name']); ?>">
                </div>
                <div class="content">
                  <h4 class="widget-title"><?php echo e($message[0]['employer']['first_name']); ?> <?php echo e($message[0]['employer']['last_name']); ?></h4>
                  <p class="text"><?php echo e($message[count($message)-1]['message']); ?></p>
                  <span class="time color-text-3 font-size-12"><?php echo e($message[0]['created_at']->diffForHumans()); ?></span>
                </div>
              </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div><!-- end mess__body -->
        </div><!-- end message-inbox-item -->
      </div><!-- message-sidebar -->
      
<!-- message-content -->
</div><!-- end dashboard-message-wrapper -->
</div><!-- end col -->
</div><!-- end row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/care_giver/message/index.blade.php ENDPATH**/ ?>