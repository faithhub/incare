
<?php $__env->startSection('admin'); ?>  

<?php if(isset($mode) && $mode == 'New'): ?>

<div class="row">
    <div class="col-lg-12">
        <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
            <div class="section-heading">
                <h2 class="sec__title">Create a Plan</h2>
            </div><!-- end section-heading -->
            <ul class="list-items d-flex align-items-center">
                <li class="active__list-item"><a href="index.html">Home</a></li>
                <li class="active__list-item">Dashboard</li>
                <li>Create a Plan</li>
            </ul>
        </div><!-- end breadcrumb-content -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->

<div class="row mt-5">
    <div class="col-lg-12">
        <div class="billing-form-item">
            <div class="billing-title-wrap">
                <h3 class="widget-title pb-0">Plan information</h3>
                <div class="title-shape margin-top-10px"></div>
            </div><!-- billing-title-wrap -->
            <div class="billing-content">                
                <div class="contact-form-action">
                    <form method="post" action="<?php echo e(url('admin/new-plan')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">                            
                            <div class="col-lg-4 column-lg-full">
                                <div class="input-box">
                                    <label class="label-text">Plan Name</label>
                                    <div class="form-group">
                                        <span class="la la-pencil-square-o form-icon"></span>
                                        <input class="form-control <?php $__errorArgs = ['plan_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" value="<?php echo e(old('plan_name')); ?>" name="plan_name" placeholder="Enter Plan Name">
                                        <?php $__errorArgs = ['plan_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-2" role="alert" style="display: block">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>                                    
                                </div>
                            </div><!-- end col-lg-4 -->
                            <div class="col-lg-4 column-lg-full">
                                <div class="input-box">
                                    <label class="label-text">Plan Types</label>
                                    <div class="form-group">
                                        <select class="job-type-option-field <?php $__errorArgs = ['plan_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="plan_type">
                                            <option value>Select Subscription Type</option>
                                            <option value="Monthly" <?php echo e(old('plan_type') == 'Monthly' ? 'selected' : ''); ?>>Monthly</option>
                                            <option value="Quarterly" <?php echo e(old('plan_type') == 'Quarterly' ? 'selected' : ''); ?>>Quarterly</option>
                                            <option value="Annually" <?php echo e(old('plan_type') == 'Annually' ? 'selected' : ''); ?>>Annually</option>
                                            
                                        </select>
                                        <?php $__errorArgs = ['plan_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-2" role="alert" style="display: block">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>                                
                            </div><!-- end col-lg-4 -->
                            <div class="col-lg-4 column-lg-full">
                                <div class="input-box">
                                    <label class="label-text">Plan Amount</label>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <span class="la form-icon">#</span>
                                                <input class="form-control <?php $__errorArgs = ['plan_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" value="<?php echo e(old('plan_amount')); ?>" name="plan_amount" placeholder="Enter Amount">
                                                <?php $__errorArgs = ['plan_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback mb-2" role="alert" style="display: block">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div><!-- end col-lg-6 -->
                                    </div><!-- end row -->
                                </div>
                            </div><!-- end col-lg-4 -->
                            <div class="col-lg-4 column-lg-full">
                                <button type="submit" class="theme-btn border-0">Add Plan</button>
                            </div>                            
                        </div><!-- end row -->
                    </form>
                </div><!-- end contact-form-action -->
            </div><!-- end billing-content -->
        </div><!-- end billing-form-item -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->
<?php elseif(isset($mode) && $mode == 'Edit'): ?> 

<div class="row">
    <div class="col-lg-12">
        <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
            <div class="section-heading">
                <h2 class="sec__title">Edit Plan</h2>
            </div><!-- end section-heading -->
            <ul class="list-items d-flex align-items-center">
                <li class="active__list-item"><a href="index.html">Home</a></li>
                <li class="active__list-item">Dashboard</li>
                <li>Edit Plan</li>
            </ul>
        </div><!-- end breadcrumb-content -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->

<div class="row mt-5">
    <div class="col-lg-12">
        <div class="billing-form-item">
            <div class="billing-title-wrap">
                <h3 class="widget-title pb-0">Plan information</h3>
                <div class="title-shape margin-top-10px"></div>
            </div><!-- billing-title-wrap -->
            <div class="billing-content">                
                <div class="contact-form-action">
                    <form method="post" action="<?php echo e(url('admin/edit-plan')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($plan->id); ?>">
                        <div class="row">                            
                            <div class="col-lg-4 column-lg-full">
                                <div class="input-box">
                                    <label class="label-text">Plan Name</label>
                                    <div class="form-group">
                                        <span class="la la-pencil-square-o form-icon"></span>
                                        <input class="form-control <?php $__errorArgs = ['plan_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" value="<?php echo e($plan->plan_name); ?>" name="plan_name" placeholder="Enter Plan Name">
                                        <?php $__errorArgs = ['plan_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-2" role="alert" style="display: block">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>                                    
                                </div>
                            </div><!-- end col-lg-4 -->
                            <div class="col-lg-4 column-lg-full">
                                <div class="input-box">
                                    <label class="label-text">Plan Types</label>
                                    <div class="form-group">
                                        <select class="job-type-option-field <?php $__errorArgs = ['plan_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="plan_type">
                                            <option value>Select Subscription Type</option>
                                            <option value="Monthly" <?php echo e($plan->plan_type == 'Monthly' ? 'selected' : ''); ?>>Monthly</option>
                                            <option value="Quarterly" <?php echo e($plan->plan_type == 'Quarterly' ? 'selected' : ''); ?>>Quarterly</option>
                                            <option value="Annually" <?php echo e($plan->plan_type == 'Annually' ? 'selected' : ''); ?>>Annually</option>
                                            
                                        </select>
                                        <?php $__errorArgs = ['plan_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback mb-2" role="alert" style="display: block">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>                                
                            </div><!-- end col-lg-4 -->
                            <div class="col-lg-4 column-lg-full">
                                <div class="input-box">
                                    <label class="label-text">Plan Amount</label>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <span class="la form-icon">#</span>
                                                <input class="form-control <?php $__errorArgs = ['plan_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" value="<?php echo e($plan->plan_amount); ?>" name="plan_amount" placeholder="Enter Amount">
                                                <?php $__errorArgs = ['plan_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback mb-2" role="alert" style="display: block">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div><!-- end col-lg-6 -->
                                    </div><!-- end row -->
                                </div>
                            </div><!-- end col-lg-4 -->
                            <div class="col-lg-4 column-lg-full">
                                <button type="submit" class="theme-btn border-0">Update Plan</button>
                            </div>                            
                        </div><!-- end row -->
                    </form>
                </div><!-- end contact-form-action -->
            </div><!-- end billing-content -->
        </div><!-- end billing-form-item -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->
                 
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/admin/plans/new_plan.blade.php ENDPATH**/ ?>