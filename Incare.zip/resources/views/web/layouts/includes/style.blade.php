{{-- 
<link rel="stylesheet" type="text/css" href="{{ asset('web/styles/bootstrap4/bootstrap.min.css') }}">
<link href="{{ asset('web/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css') }}" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="{{ asset('web/plugins/OwlCarousel2-2.2.1/owl.carousel.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('web/plugins/OwlCarousel2-2.2.1/owl.theme.default.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('web/plugins/OwlCarousel2-2.2.1/animate.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('web/styles/main_styles.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('web/styles/responsive.css') }}"> --}}


    <!-- Template CSS Files -->
    <link rel="stylesheet" href="{{ asset('web/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/font-awesome.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/line-awesome.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/owl.carousel.min.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/owl.theme.default.min.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/magnific-popup.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/daterangepicker.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/jquery-ui.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/jquery.filer.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/jquery.filer-dragdropbox-theme.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/style.css') }}">