
<?php $__env->startSection('user'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
            <div class="section-heading">
                <h2 class="sec__title">Manage My Jobs</h2>
            </div><!-- end section-heading -->
            <ul class="list-items d-flex align-items-center">
                <li class="active__list-item"><a href="#">Home</a></li>
                <li class="active__list-item"><a href="#">Dashboard</a></li>
                <li>Manage My Jobs</li>
            </ul>
        </div><!-- end breadcrumb-content -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->

<div class="row mt-5">
    <div class="col-lg-12">
        <div class="billing-form-item">
            <div class="billing-title-wrap">
                <h3 class="widget-title pb-0">Manage My Jobs</h3>
                <div class="title-shape margin-top-10px"></div>
            </div><!-- billing-title-wrap -->
            <div class="billing-content pb-0">
                <div class="manage-job-wrap">
                    <div class="table-responsive">
                        <table class="table" id="myTable" width="100%">
                            <thead>
                                <tr>
                                    <th>Job Details</th>
                                    <th>Amount/Hour</th>
                                    <th>Create On</th>
                                    <th>Application Close On</th>
                                    <th>Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                
                                <tr>
                                    <td>
                                        <div class="bread-details d-flex">
                                            <div class="bread-img flex-shrink-0">
                                                <a href="#" class="d-block">
                                                    <img src="<?php echo e(asset('uploads/jobs/'.$job->avatar)); ?>" alt="">
                                                </a>
                                            </div>
                                            <div class="manage-candidate-content">
                                                <h2 class="widget-title pb-2"><a href="#" class="color-text-2"><?php echo e($job->job_title); ?></a></h2>
                                                <p class="font-size-15">
                                                    <span class="mr-2"><i class="la la-meetup mr-1"></i>Category - <?php echo e($job->cat->name); ?></span><br>
                                                    <span class="mr-2"><i class="la la-meetup mr-1"></i>Sub Category - <?php echo e($job->sub->name); ?></span>
                                                </p>
                                            </div><!-- end manage-candidate-content -->
                                        </div>
                                    </td>
                                    <td><span class="text-success">₦<?php echo e($job->amount); ?></span></td>
                                    <td><?php echo e(date('D, M j, Y', strtotime($job->created_at))); ?></td>
                                    <td><?php echo e(date('D, M j, Y', strtotime($job->date_end))); ?></td>
                                    <td>
                                        <?php if($job->status == 'Active'): ?>
                                        <span class="badge badge-success p-1"><?php echo e($job->status); ?></span>
                                        <?php elseif($job->status == 'Blocked'): ?>
                                        <span class="badge badge-danger p-1"><?php echo e($job->status); ?></span> 
                                        <?php elseif($job->status == 'Delivered'): ?>
                                            <span class="badge badge-success p-1"><?php echo e($job->status); ?></span> 
                                        <?php else: ?>
                                        <span class="badge badge-warning p-1"><?php echo e($job->status); ?></span>                                            
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="manage-candidate-wrap">
                                            <div class="bread-action pt-0">
                                                <ul class="info-list">
                                                    <li class="d-inline-block"><a href="<?php echo e(url('employer/view-job', $job->id)); ?>" ><i class="la la-eye" data-toggle="tooltip" data-placement="top" title="View"></i></a></li>
                                                    <li class="d-inline-block"><a href="<?php echo e(url('employer/edit-job', $job->id)); ?>"><i class="la la-edit" data-toggle="tooltip" data-placement="top" title="Edit"></i></a></li>
                                                    <li class="d-inline-block"><a href="#"><i data-toggle="modal" data-target="#delete<?php echo e($job->id); ?>" class="la la-trash" data-toggle="tooltip" data-placement="top" title="Remove"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                
                                <!-- Modal Delete -->
                                <div class="modal fade" id="delete<?php echo e($job->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-body mt-2 mb-2 text-center">
                                            <h2>Are you sure you want to delete?</h2>
                                        <form method="POST" action="<?php echo e(url('employer/delete-job')); ?>">
                                            <?php echo csrf_field(); ?>                                                        
                                            <input type="hidden" name="id" value="<?php echo e($job->id); ?>">
                                            <button type="submit" class="btn btn-success m-2">Yes</button> 
                                            <button type="button" class="btn btn-dark m-2" data-dismiss="modal" aria-label="Close">No</button>
                                        </form>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!-- end billing-content -->
        </div><!-- end billing-form-item -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\laravel\Incare\resources\views/employer/jobs/manage_job.blade.php ENDPATH**/ ?>