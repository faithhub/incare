<script src="{{ asset('web/js/jquery-3.4.1.min.js') }}"></script>
<script src="{{ asset('web/js/jquery-ui.js') }}"></script>
<script src="{{ asset('web/js/popper.min.js') }}"></script>
<script src="{{ asset('web/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('web/js/owl.carousel.min.js') }}"></script>
<script src="{{ asset('web/js/jquery.magnific-popup.min.js') }}"></script>
<script src="{{ asset('web/js/isotope-3.0.6.min.js') }}"></script>
<script src="{{ asset('web/js/select2.min.js') }}"></script>
<script src="{{ asset('web/js/chart.js') }}"></script>
<script src="{{ asset('web/js/line-chart.js') }}"></script>
<script src="{{ asset('web/js/doughutchart.js') }}"></script>
<script src="{{ asset('web/js/moment.min.js') }}"></script>
<script src="{{ asset('web/js/daterangepicker.js') }}"></script>
<script src="{{ asset('web/js/purecounter.js') }}"></script>
<script src="{{ asset('web/js/jquery.filer.min.js') }}"></script>
<script src="{{ asset('web/js/jquery-nice-select.js') }}"></script>
<script src="{{ asset('web/js/smooth-scrolling.js') }}"></script>
<script src="{{ asset('web/js/progresscircle.js') }}"></script>
<script src="{{ asset('web/js/main.js') }}"></script>
<script>
    (function ($) {
        "use strict"; //use of strict
        $(function () {
            $('select').niceSelect();
        });
    })(jQuery);

</script>

<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable({
"scrollX": true
} );
    });
</script>