<div class="row">
	<div class="col-lg-12">
		<div class="copy-right margin-top-40px padding-top-20px padding-bottom-20px">
			<p class="copy__desc">
				Copyright &copy;2020 Zobstar Inc. Made with
				<span class="la la-heart-o"></span> by <a href="https://themeforest.net/user/techydevs/portfolio">TechyDevs</a>
			</p>
			<ul class="list-items">
				<li><a href="#">Terms of Use,</a></li>
				<li><a href="#">Privacy Policy</a></li>
			</ul>
		</div><!-- end copy-right -->
	</div><!-- end col-lg-12 -->
</div><!-- end row -->